# ENTRE — cidade em pausa

Estudo original de identidade e campanha para um encontro cultural fictício. Criado neste redesenho com assistência de IA; não representa um cliente contratado, um evento realizado ou uma comprovação da experiência profissional de Kayk.

## Desafio proposto

Como tornar visível a ideia de desacelerar em uma cidade que disputa atenção a cada esquina? O exercício imagina uma marca cultural para aproximar música, arte e conversa sem depender de artistas conhecidos, fotografias de terceiros ou números de público.

## Ideia

“A cidade respira.” A pausa vira linguagem: dois traços, um intervalo, um portal. Arcos e círculos lembram passagens e pontos de encontro; os espaços vazios sustentam a composição tanto quanto as formas preenchidas.

## Sistema visual

Laranja `#ff693b`, papel `#f1e9da` e preto `#171713`. Tipografia pesada para identificação a distância; texto curto e filetes para organizar a informação. A mesma gramática se adapta ao cartaz, à publicação quadrada e ao ingresso demonstrativo.

## Entregas produzidas

- Cartaz: 900 × 1200 px, marca dividida em duas linhas, arcos em par e assinatura editorial.
- Social: 1080 × 1080 px, arquitetura modular e chamada com respiro.
- Ingresso demonstrativo: 1400 × 600 px, canhoto contrastante, símbolo de pausa e aviso explícito de ausência de validade.

Cada peça possui arquivo nativo `.vectorcraft` com objetos nomeados e texto editável, SVG com texto, SVG com texto convertido em curvas e PNG. As versões com curvas são as recomendadas para exibição no site, porque não dependem de fontes instaladas no visitante.

O conjunto também possui um painel de apresentação vetorial de 1600 × 1000 px e uma vinheta silenciosa de quatro segundos, produzida em EffectCraft com camadas e keyframes editáveis. Na vinheta, duas barras de pausa se afastam e voltam, abrindo um intervalo na composição. O MP4 de 600 × 400 px acompanha um quadro estático para quem preferir menos movimento.

## Processo realmente realizado

Briefing e direção assistidos por IA; construção vetorial original por comandos de formas, curvas e texto no VectorCraft 0.12.0 instalado; composição e animação original no EffectCraft 0.10.0; exportação e reabertura pelas CLIs oficiais. Os logs e roteiros reproduzíveis acompanham os arquivos. Nenhuma imagem ou marca de terceiros foi copiada. Arial é uma fonte do sistema; nenhum arquivo de fonte é distribuído.

## Critério de avaliação

Consistência entre formatos, hierarquia da marca e legibilidade da chamada. As três peças foram abertas como PNG para inspeção visual. A sobreposição inicial entre texto e arco do cartaz foi corrigida antes da entrega. A reabertura dos arquivos nativos não reportou avisos, fontes ausentes ou glifos ausentes.

Não há métricas de conversão, audiência, comparecimento ou vendas: a campanha é uma proposta visual não veiculada.
